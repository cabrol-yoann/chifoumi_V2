#include "tablescore.h"
#include "ui_tablescore.h"
#include <QDebug>
#include <QSqlQuery>

tablescore::tablescore(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::tablescore)
{
    ui->setupUi(this);
}

tablescore::~tablescore()
{
    delete ui;
}

void tablescore::afficherScore()
{
    db->openDataBase();
    qDebug()<<"test";
    QSqlQuery query;
    query.exec("SELECT nomJoueurHumain,scoreJoueurHumain FROM TableauChifoumi WHERE gagnant='Joueur'");
    qDebug()<<"test";
    for (int i=0;query.next();i++)
    {
        qDebug()<<i;
        qDebug()<<"test2";
        ui->tableWidget->insertRow(i);
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(query.value(0).toString()));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(query.value(1).toString()));
        qDebug()<<query.value(0)<<query.value(1);
    }
    this->show();
    db->closeDataBase();
}
