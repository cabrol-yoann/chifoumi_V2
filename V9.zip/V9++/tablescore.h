#ifndef TABLESCORE_H
#define TABLESCORE_H

#include <QDialog>
#include "database.h"

namespace Ui {
class tablescore;
}

class tablescore : public QDialog
{
    Q_OBJECT

public:
    explicit tablescore(QWidget *parent = nullptr);
    ~tablescore();
    void afficherScore();

private:
    Ui::tablescore *ui;
    Database *db=new Database();
};

#endif // TABLESCORE_H
